/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=32x32 pirate pirate.jpeg 
 * Time-stamp: Monday 11/19/2018, 00:25:38
 * 
 * Image Information
 * -----------------
 * pirate.jpeg 32@32
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PIRATE_H
#define PIRATE_H

extern const unsigned short pirate[1024];
#define PIRATE_SIZE 2048
#define PIRATE_LENGTH 1024
#define PIRATE_WIDTH 32
#define PIRATE_HEIGHT 32

#endif

