/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=16x16 fBWUpLeft fBWUpLeft.png 
 * Time-stamp: Wednesday 11/21/2018, 04:06:30
 * 
 * Image Information
 * -----------------
 * fBWUpLeft.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FBWUPLEFT_H
#define FBWUPLEFT_H

extern const unsigned short fBWUpLeft[256];
#define FBWUPLEFT_SIZE 512
#define FBWUPLEFT_LENGTH 256
#define FBWUPLEFT_WIDTH 16
#define FBWUPLEFT_HEIGHT 16

#endif

