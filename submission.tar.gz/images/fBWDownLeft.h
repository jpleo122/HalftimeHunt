/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=16x16 fBWDownLeft fBWDownLeft.png 
 * Time-stamp: Wednesday 11/21/2018, 04:06:40
 * 
 * Image Information
 * -----------------
 * fBWDownLeft.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FBWDOWNLEFT_H
#define FBWDOWNLEFT_H

extern const unsigned short fBWDownLeft[256];
#define FBWDOWNLEFT_SIZE 512
#define FBWDOWNLEFT_LENGTH 256
#define FBWDOWNLEFT_WIDTH 16
#define FBWDOWNLEFT_HEIGHT 16

#endif

