/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 basicBackground basicBackground.png 
 * Time-stamp: Tuesday 11/20/2018, 09:02:46
 * 
 * Image Information
 * -----------------
 * basicBackground.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BASICBACKGROUND_H
#define BASICBACKGROUND_H

extern const unsigned short basicBackground[38400];
#define BASICBACKGROUND_SIZE 76800
#define BASICBACKGROUND_LENGTH 38400
#define BASICBACKGROUND_WIDTH 240
#define BASICBACKGROUND_HEIGHT 160

#endif

