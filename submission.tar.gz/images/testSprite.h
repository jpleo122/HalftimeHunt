/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=32x32 testSprite testSprite.png 
 * Time-stamp: Wednesday 11/21/2018, 03:51:01
 * 
 * Image Information
 * -----------------
 * testSprite.png 32@32
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TESTSPRITE_H
#define TESTSPRITE_H

extern const unsigned short testSprite[1024];
#define TESTSPRITE_SIZE 2048
#define TESTSPRITE_LENGTH 1024
#define TESTSPRITE_WIDTH 32
#define TESTSPRITE_HEIGHT 32

#endif

