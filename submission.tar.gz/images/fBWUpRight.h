/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=16x16 fBWUpRight fBWUpRight.png 
 * Time-stamp: Wednesday 11/21/2018, 04:06:19
 * 
 * Image Information
 * -----------------
 * fBWUpRight.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FBWUPRIGHT_H
#define FBWUPRIGHT_H

extern const unsigned short fBWUpRight[256];
#define FBWUPRIGHT_SIZE 512
#define FBWUPRIGHT_LENGTH 256
#define FBWUPRIGHT_WIDTH 16
#define FBWUPRIGHT_HEIGHT 16

#endif

