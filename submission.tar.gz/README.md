My version of #IDARB's Halftime Hunt game.

Use the arrow keys to move your gun, and press "B" (x on the keyboard) to shoot up at the ducks.

Press select (back space on keyboard) to return to the title screen at any time.